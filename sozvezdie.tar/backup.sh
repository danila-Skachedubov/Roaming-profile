#!/bin/bash
echo Running backup script
USER_NAME=$(whoami)

readonly REMOTE_PATH=$USER_NAME@dc.domain.alt:/home/DOMAIN/$USER_NAME
readonly LOCAL_PATH=/home/DOMAIN.ALT/$USER_NAME

rsync -avz -f'- /.*' $LOCAL_PATH/ $REMOTE_PATH
