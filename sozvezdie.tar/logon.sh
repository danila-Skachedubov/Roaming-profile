#!/bin/bash
echo Running logon script
USER_NAME=$(whoami)

readonly REMOTE_PATH=$USER_NAME@dc.domain.alt:/home/DOMAIN/$USER_NAME
readonly LOCAL_PATH=/home/DOMAIN.ALT/$USER_NAME

rsync -avz -f'- /.*' -e "ssh -o StrictHostKeyChecking=no -o BatchMode=yes" $REMOTE_PATH/ $LOCAL_PATH
